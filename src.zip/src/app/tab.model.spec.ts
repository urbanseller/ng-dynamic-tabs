import { Tab.Model } from './tab.model';

describe('Tab.Model', () => {
  it('should create an instance', () => {
    expect(new Tab.Model()).toBeTruthy();
  });
});
