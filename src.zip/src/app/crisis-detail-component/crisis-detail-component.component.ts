import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crisis-detail-component',
  templateUrl: './crisis-detail-component.component.html',
  styleUrls: ['./crisis-detail-component.component.css']
})
export class CrisisDetailComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
