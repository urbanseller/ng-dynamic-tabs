export interface ITab {
    name: string;
    url: string;
  }
  