import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainContentComponent } from './main-content/main-content.component';
import { MenuesComponent } from './menues/menues.component';
import { MenuComponent } from './menu/menu.component';
import { MoviesComponent } from "./movies/movies.component";
import { SongsComponent } from './songs/songs.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { TabConfigComponent } from './tab-config/tab-config.component';
import { CrisisListComponentComponent } from './crisis-list-component/crisis-list-component.component';
import { CrisisDetailComponentComponent } from './crisis-detail-component/crisis-detail-component.component';
import { CrisisCenterHomeComponentComponent } from './crisis-center-home-component/crisis-center-home-component.component';
import { PagesModule } from './pages/pages.module';

@NgModule({
  declarations: [
    AppComponent,
    MainContentComponent,
    MenuesComponent,
    MenuComponent,
    MoviesComponent,
    SongsComponent,
    MovieDetailsComponent,
    TabConfigComponent,
    CrisisListComponentComponent,
    CrisisDetailComponentComponent,
    CrisisCenterHomeComponentComponent
  ],
  imports: [
    PagesModule,
    BrowserModule,
    AppRoutingModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
