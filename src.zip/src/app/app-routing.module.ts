import {RouterModule, Routes} from '@angular/router';
import {NgModule} from '@angular/core';
import { MoviesComponent } from "./movies/movies.component";
import {SongsComponent} from './songs/songs.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { CrisisListComponentComponent } from './crisis-list-component/crisis-list-component.component';
import { CrisisDetailComponentComponent } from './crisis-detail-component/crisis-detail-component.component';
import { CrisisCenterHomeComponentComponent } from './crisis-center-home-component/crisis-center-home-component.component';
import { LoginComponent } from './pages/login/login.component';
import { MainComponent } from './pages/main/main.component';

const routes: Routes = [

  // {
  //   path: 'login',
  //   component: LoginComponent,
  // },
  // {
  //   path: '',
  //   component:MainComponent,
  // },

  {
    path: 'movies',
    component: MoviesComponent,
  },

  {
    path: 'movie/:id',
    component: MovieDetailsComponent,
  },
  {
    path: 'songs',
    component: SongsComponent 
    // ,
    // children: [
    //   {
    //     path:'',
    //     component: CrisisListComponentComponent,
    //     children: [
    //       {
    //         path: 'toto',
    //         component: CrisisDetailComponentComponent 
    //       },
    //       {
    //         path: '',
    //         component: CrisisCenterHomeComponentComponent
    //       }
    //     ]
    //   }
    // ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
