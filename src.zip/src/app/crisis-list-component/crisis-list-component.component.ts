import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crisis-list-component',
  templateUrl: './crisis-list-component.component.html',
  styleUrls: ['./crisis-list-component.component.css']
})
export class CrisisListComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
