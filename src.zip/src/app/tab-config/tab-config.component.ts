import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-config',
  templateUrl: './tab-config.component.html',
  styleUrls: ['./tab-config.component.css']
})
export class TabConfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
