import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menues',
  templateUrl: './menues.component.html',
  styleUrls: ['./menues.component.css']
})
export class MenuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
