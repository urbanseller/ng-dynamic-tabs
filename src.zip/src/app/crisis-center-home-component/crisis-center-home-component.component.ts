import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crisis-center-home-component',
  templateUrl: './crisis-center-home-component.component.html',
  styleUrls: ['./crisis-center-home-component.component.css']
})
export class CrisisCenterHomeComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
